# OPC UA 链路测试用例表（模板）

> 分层执行：连通性 → 数据正确性 → 订阅与事件 → 异常与恢复 → 压力边界。前一层不通过不进入下一层。
> 判定依据一律写具体的 StatusCode 名称或 Wireshark 报文，禁止写"看起来正常"。

## 测试环境

| 项 | 值 |
|---|---|
| Server | asyncua / open62541（版本） |
| 端点 URL | opc.tcp://xxx:4840/ |
| Security Policy / Mode | None / Basic256Sha256 + Sign&Encrypt |
| 客户端 | UaExpert（版本）、Node-RED（版本） |
| 抓包 | Wireshark，过滤器 `tcp.port == 4840`、`opcua` |

## 用例表

| 编号 | 分层 | 场景 | 前置条件 | 操作步骤 | 预期结果 | 判定依据 | 实际结果 | 结论 |
|---|---|---|---|---|---|---|---|---|
| TC-01 | 连通性 | 无安全策略连接 | Server 已启动 | UaExpert 添加端点 → 连接 | 连接成功，可 Browse | 无 BadCertificate* / BadTimeout | | |
| TC-02 | 连通性 | 证书未信任 | Server 启用 Basic256Sha256 | 首次连接 | 报 BadCertificateUntrusted | UaExpert 提示 + Server rejected 目录出现证书 | | |
| TC-03 | 连通性 | 证书加入 trusted | TC-02 之后 | 移动证书到 trusted → 重连 | 连接成功 | 无 Bad 状态码 | | |
| TC-04 | 数据正确性 | 读取标量变量 | 已连接 | Read 目标变量 | 值与量程一致 | Value/StatusCode/SourceTimestamp 三项均正确 | | |
| TC-05 | 数据正确性 | 数据类型与量程边界 | 已连接 | 写入超量程值 | 被拒绝或钳制 | 返回预期 StatusCode，非 Good | | |
| TC-06 | Method | 正常调用建单 Method | 已连接 | 输入合法参数调用 | 返回 ResultCode=0 与工单号 | 输出参数非空 | | |
| TC-07 | Method | 幂等性 | 已建单 | 用同一幂等键重复调用 | 不产生重复工单 | 返回同一工单号 | | |
| TC-08 | Method | 非法参数 | 已连接 | 传入空工单号 | 明确失败 | ResultCode≠0，不是 Good | | |
| TC-09 | 订阅 | MonitoredItem 数据变化 | 已建立订阅 | 改变变量值 | 客户端收到 Publish 通知 | Wireshark 可见 PublishResponse | | |
| TC-10 | 订阅 | 无变化不刷屏 | 已配置 Deadband | 微小波动 | 不触发通知 | Publish 数量不增长 | | |
| TC-11 | 事件 | NG 事件订阅 | 已订阅自定义 EventType | 触发一次 NG | 收到一条事件，字段齐全 | EventId/Time/Severity 均存在 | | |
| TC-12 | 事件 | 洪水去重 | 已订阅 | 短时连续触发同一 FrameNo | 只收到一条 | 事件计数 | | |
| TC-13 | 异常 | Server 进程被杀 | 已订阅 | kill server | 客户端收到断连通知 | BadSessionClosed / StatusChangeNotification | | |
| TC-14 | 异常 | 断网 N 秒后恢复 | 已订阅 | 禁用网卡 → 等待超过 LifetimeCount → 恢复 | 订阅失效后客户端重建，数据恢复 | BadNoSubscription / BadTimeout，恢复后重新 CreateSubscription | | |
| TC-15 | 异常 | 短时抖动未超 Lifetime | 已订阅 | 断网 < LifetimeCount | 订阅存活，KeepAlive 恢复 | 无 BadNoSubscription | | |
| TC-16 | 异常 | 回调 MES 超时 | Node-RED 已部署 | 停掉模拟 MES | 不丢数据、有重试或落盘 | 重试计数/落盘文件 | | |
| TC-17 | 压力 | 高并发 MonitoredItem | 已连接 | 建立 N×M 个监控项 | 达到目标发布间隔 | 实测 PublishingInterval 偏差 | | |
| TC-18 | 压力 | 队列溢出 | QueueSize 较小 | 突发大量变化 | 按 DiscardOldest 策略丢弃 | 可见 QueueOverflow 指示 | | |

## 代码评审意见表

| 编号 | 位置（文件/行/节点） | 问题描述 | 违反条款/规范 | 风险等级(P0/P1/P2) | 修改建议 |
|---|---|---|---|---|---|

## 优化建议清单

| 编号 | 建议 | 优先级 | 预期收益 | 实施成本 | 是否上线前必改 |
|---|---|---|---|---|---|

## 总体结论

- 结论：可交付 / 有条件交付 / 不可交付
- 阻塞项：
- 遗留风险与补充测试建议：
