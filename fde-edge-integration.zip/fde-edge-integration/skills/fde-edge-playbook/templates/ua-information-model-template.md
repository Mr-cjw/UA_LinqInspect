# OPC UA 信息模型定义表（模板）

> 用法：按"层级 → 对象 → 成员"三段填写。NodeId 命名空间约定：`ns=1` 为本项目自定义。

## 0. 命名空间声明

| 命名空间索引 | URI | 说明 |
|---|---|---|
| 0 | http://opcfoundation.org/UA/ | 标准命名空间 |
| 1 | urn:{company}:{line}:UA | 本项目自定义 |

## 1. 地址空间层级

```
Objects
└── {Line}:{产线对象}
    └── {Station}:{工位对象}
        └── {Device}:{设备对象}
            ├── {测点变量}
            └── {AI判定对象}
```

## 2. Object 清单

| NodeId | BrowseName | 父节点 | TypeDefinition | 说明 |
|---|---|---|---|---|
| ns=1;s=Line.01 | Line01 | Objects | 自定义 LineType | 产线 |
| ns=1;s=Line.01.Station.10 | Station10 | Line01 | 自定义 StationType | 质检工位 |

## 3. Variable 清单

| NodeId | BrowseName | 父节点 | DataType | ValueRank | AccessLevel | 单位/量程 | Historizing | 语义说明 |
|---|---|---|---|---|---|---|---|---|
| ns=1;s=... | Temperature | ... | Double | -1 | CurrentRead | °C / 0~120 | false | 工位温度 |
| ns=1;s=... | AiVerdict | ... | String | -1 | CurrentRead | OK/NG | true | AI 判定结果 |
| ns=1;s=... | AiConfidence | ... | Double | -1 | CurrentRead | 0~1 | true | 判定置信度 |

## 4. Method 清单

| NodeId | BrowseName | 挂载 Object | 输入参数 | 输出参数 | 幂等性 | 失败语义 | 说明 |
|---|---|---|---|---|---|---|---|
| ns=1;s=... | CreateDefectWorkOrder | 工单对象 | WorkOrderId:String, DefectCode:String, Severity:UInt16 | ResultCode:Int32, DefectWoId:String | 同 WorkOrderId+DefectCode 只建一次 | ResultCode≠0 + StatusCode | 建不良工单 |
| ns=1;s=... | ReportProduction | 工单对象 | WorkOrderId:String, GoodQty:UInt32, ScrapQty:UInt32 | ResultCode:Int32 | 否，按报工流水号去重 | ResultCode≠0 | 报工 |

## 5. Event 清单

| EventType | BrowseName | 继承 | 自定义字段 | Severity 范围 | 触发条件 | 去重策略 |
|---|---|---|---|---|---|---|
| 自定义 AiNgEventType | AiNgEvent | BaseEventType | WorkOrderId:String, DefectCode:String, Confidence:Double, FrameNo:UInt64 | 1~1000 | AI 判定为 NG 且通过复检规则 | 同一 FrameNo 只发一次 |

## 6. 订阅配置

| 订阅组 | PublishingInterval(ms) | SamplingInterval(ms) | QueueSize | DiscardOldest | Deadband | 用途 |
|---|---|---|---|---|---|---|
| 实时判定 | 250 | 100 | 10 | true | — | NG 事件驱动 |
| 慢变量 | 5000 | 1000 | 1 | true | 绝对值 | 环境监测 |

## 7. MES 消费契约

| 交互方向 | 方式 | 目标 | 字段 | 频率/触发 | 重试与幂等 |
|---|---|---|---|---|---|
| MES → UA | Method 调用 | CreateDefectWorkOrder | WorkOrderId/DefectCode/Severity | NG 事件触发 | 幂等键 = WorkOrderId+FrameNo |
| UA → MES | Event 订阅 | AiNgEvent | 见上 | 事件驱动 | EventId 去重 |
| MES → UA | Variable 读 | 工单状态 | — | 按需 | — |
