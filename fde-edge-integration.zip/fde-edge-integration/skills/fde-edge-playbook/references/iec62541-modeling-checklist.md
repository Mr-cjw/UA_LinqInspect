# OPC UA 信息模型评审检查清单

依据 IEC 62541（Part 3 Address Space、Part 4 Services、Part 5 Information Model）。评审信息模型时逐项打勾，任一 ❌ 必须回到主理人重新设计。

## 1. 标识与命名

- [ ] NodeId 命名空间（ns）划分明确：ns=0 标准，ns=1 本项目自定义，ns≥2 引入的 Companion Spec
- [ ] NodeId 使用 String 或 Numeric 且**风格统一**，不混用
- [ ] BrowseName 使用驼峰或 Pascal 命名，与 NodeId 语义一致
- [ ] DisplayName 与 Description 已填写（含中文 + 英文），Description 不为空
- [ ] 没有出现"临时变量1""test""aaa"之类的占位命名

## 2. Object 与类型

- [ ] 每个设备/工位/产线抽象为 Object，且有明确 ObjectType（优先复用标准类型，其次自定义子类型）
- [ ] ObjectType 的实例化关系清晰（HasTypeDefinition 指向的类型是存在的）
- [ ] 层级组织符合现场语义（如 产线 → 工位 → 设备 → 测点），不是拍脑袋的扁平堆
- [ ] 引用（Reference）方向正确，Organizes / HasComponent / HasProperty 使用恰当

## 3. Variable

- [ ] DataType 明确且是标准类型或已注册的自定义类型
- [ ] ValueRank 与 ArrayDimensions 正确（标量 -1，一维数组 1）
- [ ] AccessLevel（CurrentRead / CurrentWrite）与用户实际需求匹配，不该写的绝不开放写
- [ ] 工程单位（EngineeringUnits）、量程（EURange）作为 Property 给出
- [ ] 需要历史回溯的变量已开启 Historizing
- [ ] 采样/发布语义清楚：谁改值、多久改一次、客户端是订阅还是轮询
- [ ] StatusCode 与时间戳（SourceTimestamp / ServerTimestamp）会被正确写入，不伪造 Good

## 4. Method

- [ ] Method 挂在语义上正确的 Object 下（建单挂工单对象，不挂根对象）
- [ ] InputArguments 与 OutputArguments 已声明，每个参数有 Name / DataType / Description
- [ ] 参数类型不是"万能 String"（不要把结构化数据塞进字符串）
- [ ] 幂等性已定义：重复调用同一个 Method 会怎样
- [ ] 失败语义明确：返回什么 StatusCode，业务错误是否区分于通信错误
- [ ] 没有用"写变量触发动作"来替代 Method

## 5. Event

- [ ] 有明确的 EventType（继承 BaseEventType 或自定义子类型）
- [ ] 事件字段齐全：EventId、EventType、SourceNode、Time、Severity、Message
- [ ] 自定义字段有明确 DataType 与语义（如 WorkOrderId、DefectCode、Confidence）
- [ ] 触发条件是"发生了某件事"，而不是"状态持续为真"
- [ ] 去重与洪水控制已考虑（同一 NG 是否只发一次）
- [ ] Severity 分级有意义（不只是全部设 100）

## 6. 订阅与服务质量

- [ ] PublishingInterval / SamplingInterval 与业务节奏匹配
- [ ] QueueSize 与 DiscardOldest 策略已定义
- [ ] Deadband / DataChangeFilter 已按需配置（避免无意义刷屏）
- [ ] LifetimeCount / KeepAliveCount 与断网恢复预期匹配

## 7. 安全与合规红线

- [ ] 没有把业务错误伪装成 Good
- [ ] 没有硬编码证书私钥或明文口令在代码里
- [ ] 安全策略与用户实际部署环境一致（原型可 None，文档须说明生产应用 Basic256Sha256 + 证书信任）
- [ ] 没有任何地方退化成 "HTTP 拉 PLC 数据" 的 Web 后端范式

## 8. 面向 MES 的可消费性

- [ ] MES 侧要读的 Variable、要调的 Method、要订阅的 Event 都能一一指认
- [ ] 工单号 / 批次号 / 工位号 在所有相关节点上可关联（能正查也能反查）
- [ ] 追溯所需字段（缺陷码、时间、设备、操作员、置信度）齐全
