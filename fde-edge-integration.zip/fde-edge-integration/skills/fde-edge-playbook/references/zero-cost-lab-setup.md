# 零成本实验环境搭建顺序

原则：**先软件后硬件，先跑通后优化，先链路后性能。** 每一级跑通并被验证后，才允许进入下一级。

## Level 0：本机 / WSL（默认起点，0 成本）

| 组件 | 用途 | 安装要点 |
|---|---|---|
| Python 3.10+ | asyncua Server / Client、YOLOv8 | `python -m venv .venv` |
| `asyncua` | Python 侧 OPC UA Server | `pip install asyncua` |
| `opcua-client` / `asyncua` CLI | 命令行侧验证 | `pip install opcua-client` |
| UaExpert（免费，需注册下载） | 图形化验证连通性、订阅、Method、Event | Windows 本机最方便 |
| Wireshark（免费） | 抓 4840 端口 OPC UA 报文 | 自带 `opcua` 解析器 |
| Node-RED | 编排层 | `npm install -g node-red` + `npm install node-red-contrib-opcua` |
| open62541（源码构建） | C 侧 Server，与 Python 方案互为对照 | `git clone` + `cmake` |
| YOLOv8（`ultralytics`） | 边缘 AI 质检 | `pip install ultralytics`，无权重时降级为虚拟传感器 |

**验证闭环**：本机起 asyncua Server → UaExpert 连上并订阅 → Node-RED 订阅并分支 → 模拟 MES 收到回调 → 回执写回 UA 节点。全通过才算 Level 0 完成。

## Level 1：WSL / Docker 多节点（0 成本，进阶）

- 在 WSL2 或 Docker 里跑 open62541 C Server，Windows 本机的 UaExpert 与 Node-RED 跨机连接
- 目的：验证跨主机、跨网段行为，练习防火墙与端口问题，为断网测试做准备
- 注意 WSL2 的 IP 与端口转发，端点 URL 要用实际可达地址

## Level 2：树莓派（低成本，可选）

- 目的：验证资源受限（内存/CPU）环境下 open62541 的表现，练习交叉编译与 systemd 守护
- 前置：Level 0/1 功能已全部跑通、并已确认"确实需要搬到边缘盒子"
- 关键动作：裁剪 CMake 选项、量化内存占用、做长时间稳定性观察

## Level 3：STM32 + FreeRTOS（最后，仅在明确需要时）

- 目的：验证裸机/RTOS 上的 UA Server 可行性、内存池与任务栈估算
- 前置：已能用树莓派跑通、且明确有成本/功耗/体积约束要求
- 关键动作：`UA_ARCHITECTURE_FREERTOSLWIP`、静态内存池、单线程配置、栈溢出检测

## 成本控制红线

- 用户未明确要求上硬件时，**不产出 Level 2/3 方案**
- 任何硬件建议必须附带"为什么软件仿真不够"的理由
- 采购清单只在用户明确要买时才给，且给出最便宜可行选项

## 常见零成本替代方案

| 真实场景 | 零成本替代 |
|---|---|
| 真实相机 + 产线 | 视频文件 / 图片集循环推理，或虚拟传感器直出判定 |
| 真实 PLC | open62541 或 asyncua 起一个模拟 Server |
| 真实 Modbus 从站 | 软件模拟 Modbus TCP Server |
| 真实 MES | Node-RED `http in` + `http response` 假扮 MES 接收端 |
| 真实网络故障 | 拔网线 / 关进程 / 防火墙规则 / `iptables DROP` |
