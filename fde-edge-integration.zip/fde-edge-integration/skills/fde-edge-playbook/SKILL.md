---
name: fde-edge-playbook
description: 工业FDE边缘集成攻坚组的共享作业手册。当任务涉及 OPC UA / open62541 / asyncua / 嵌入式移植 / 边缘AI质检 / Node-RED / MES 工单闭环时加载，用于对齐统一规则、信息模型规范、零成本实验环境、测试用例与简历话术模板。
---

# FDE 边缘集成 Playbook

本手册是【工业FDE边缘集成攻坚组】所有角色的共同约束与共用素材。任何成员在产出前都应先对齐本手册。

## 统一规则（六条，不可违背）

1. **服务 FDE 学生学习**：交付物要"能跑 + 能讲 + 能学到"。先讲"为什么"，再给实现，禁止只丢代码或只丢结论。
2. **零成本软件仿真优先，硬件后置控投入**：顺序为 本机/WSL → 树莓派 → STM32+FreeRTOS。用户未明确要求上硬件时，默认不产出硬件方案。
3. **严格遵循 IEC 62541**：术语、节点类、StatusCode、地址空间组织均按规范，引用时标注具体 Part 与章节。
4. **目标链路唯一**：`AI/传感器 → OPC UA Server → Node-RED → 模拟 MES 工单闭环`。
5. **禁止 Web 后端思路**：不得用 REST 资源 / 微服务 / ORM / 前后端分离范式设计工业链路。交互走 Variable 读写、Method 调用、Event 通知、Subscription/MonitoredItem 订阅。Node-RED 的 `http in` 仅作为"模拟 MES 接收端"的仿真道具，必须明示。
6. **交付结束附简历话术**：项目描述、技术要点、量化结果、面试追问预判。

## IEC 62541 速查

| Part | 内容 | 何时引用 |
|---|---|---|
| Part 1 | Overview / Concepts | 讲清 OPC UA 是什么、为什么 |
| Part 3 | Address Space Model | 节点类、Reference、NodeId、BrowseName 建模 |
| Part 4 | Services | Read/Write/Call/CreateSubscription/Publish 等服务语义 |
| Part 5 | Information Model | 标准 ObjectType/VariableType/EventType |
| Part 6 | Mappings | 编码、UA TCP、安全通道 |
| Part 7 | Profiles | 选型与能力声明 |
| Part 11 | Historical Access | 历史数据存储与读取 |

## 建模决策规则

| 要表达的东西 | 该用什么 | 不该用什么 |
|---|---|---|
| 持续变化的测量值 | Variable + Subscription/MonitoredItem | 客户端轮询 REST |
| 让 Server 做一件事（建单、报工、复检） | Method（带输入/输出参数） | 写一个"命令变量"再轮询 |
| 发生了某件事（NG、超阈值、停机） | Event（自定义 EventType + 订阅） | 靠变量翻转做边沿检测 |
| 静态描述信息（量程、单位、型号） | Property / Variable with description | 硬编码在客户端 |
| 历史回溯 | Historizing + Historical Access | 自己在应用层存表 |

## 资源索引

### references/
- `iec62541-modeling-checklist.md` — 信息模型评审检查清单（Object/Variable/Method/Event 逐项）
- `zero-cost-lab-setup.md` — 零成本实验环境搭建顺序与命令清单
- `resume-talking-points.md` — FDE 方向简历话术与面试追问框架

### templates/
- `ua-information-model-template.md` — 信息模型定义表模板
- `test-case-template.md` — 测试用例表模板
- `nodered-flow-template.json` — Node-RED 流骨架（可导入，需按实际节点调整）

## 使用方式

- **主理人**：Phase 0 建模时加载 `references/iec62541-modeling-checklist.md` 与 `templates/ua-information-model-template.md`；Phase 4 加载 `references/resume-talking-points.md`。
- **ua-embedded-c-engineer / python-edge-app-engineer**：实现前对齐建模决策规则；环境搭建参考 `references/zero-cost-lab-setup.md`。
- **nodered-flow-engineer**：以 `templates/nodered-flow-template.json` 为骨架扩展。
- **ua-test-validation-engineer**：用例一律用 `templates/test-case-template.md` 的结构。
- **mes-industrial-consultant**：建模决策规则中的"该用什么/不该用什么"即为其接口契约依据。
