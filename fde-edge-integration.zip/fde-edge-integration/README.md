# 工业FDE边缘集成攻坚组（fde-edge-integration）

面向工业 FDE（前沿部署工程师）方向学习与原型交付的六角色协作专家团：贯通 AI/传感器 → OPC UA Server → Node-RED → 模拟 MES 工单闭环。

## 类型

Team 型（多角色协作团队）· 分类：02-Engineering（技术工程）

## 团队成员

| 角色 | 成员 ID | 名字 | 核心交付物 |
|---|---|---|---|
| FDE方案架构师（主理人） | `fde-edge-integration-team-lead` | 乔贯通 | 需求拆解、信息模型与接口设计、排期、简历话术 |
| 嵌入式C与OPC UA工程师 | `ua-embedded-c-engineer` | 崔裁峰 | 注释完整 C 源码、CMake 脚本、移植文档 |
| Python边缘应用工程师 | `python-edge-app-engineer` | 苏跑通 | 可运行 Python 代码、依赖清单、运行验证步骤 |
| 工业自动化与MES顾问 | `mes-industrial-consultant` | 郝讲明 | 业务口径、字段定义表、接口契约（不写代码） |
| 低代码工作流工程师 | `nodered-flow-engineer` | 连得通 | 可导入的 Node-RED JSON 流文件 |
| 测试验证工程师 | `ua-test-validation-engineer` | 查分明 | 测试用例表、抓包分析、评审意见、优化建议 |

## 统一规则

1. 服务 FDE 学生学习：能跑 + 能讲 + 能学到东西
2. 零成本软件仿真优先，硬件后置控投入（本机/WSL → 树莓派 → STM32+FreeRTOS）
3. 严格遵循 IEC 62541（引用时标注 Part 与章节）
4. 目标链路唯一：AI/传感器 → OPC UA Server → Node-RED → 模拟 MES 工单闭环
5. 禁止 Web 后端思路（不用 REST/微服务/ORM 范式设计工业链路）
6. 交付结束附 FDE 简历话术

## 功能

- **全链路原型交付**（默认 Workflow）：需求拆解 → 信息模型设计 → Python 侧 Server + AI 对接 → Node-RED 编排与 MES 回调 → 测试验证 → 简历话术
- **单点问题直调**：C/编译、Python/AI、MES 业务口径、Node-RED 编排、连通性抓包，按域路由到对应成员
- **简历包装**：项目描述、技术栈、STAR 结构、量化结果、面试追问预判

## 使用示例

- 我要在零成本软件仿真环境下打通一条 AI质检 → OPC UA Server → Node-RED → 模拟MES工单闭环 的原型链路，请拆解需求、设计信息模型并给出排期。
- 评审我的 OPC UA 信息模型，检查 Object/Variable/Method/Event 设计是否符合工厂质检工单规范和 IEC 62541。
- 把这套工业边缘集成原型包装成 FDE 方向的简历话术、项目描述和面试要点。

## 附带技能包

`skills/fde-edge-playbook` — 团队共享作业手册：

- `references/iec62541-modeling-checklist.md` — 信息模型评审检查清单
- `references/zero-cost-lab-setup.md` — 零成本实验环境搭建顺序
- `references/resume-talking-points.md` — FDE 简历话术与面试框架
- `templates/ua-information-model-template.md` — 信息模型定义表模板
- `templates/test-case-template.md` — 测试用例表模板
- `templates/nodered-flow-template.json` — Node-RED 流骨架

## 头像

头像位于 `avatars/` 目录（团队 1 张 + 主理人 1 张 + 团员 5 张）。如需替换为自定义头像，要求：
- 格式：PNG（推荐）或 JPG
- 尺寸：512×512 px
- 大小：单张不超过 500KB

## 安装

专家包目录位于：

```
C:\Users\XunMengTong\.workbuddy\plugins\marketplaces\my-experts\plugins\fde-edge-integration\
```

注册命令：

```bash
python3 scripts/register_expert.py <expert-dir>
```

## 打包分享

```bash
python3 scripts/package_expert.py <expert-dir> [output-dir]
```
